// This file is for declaring modules which do not have type declaration files
declare module "react-rewards";
